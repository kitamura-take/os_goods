# Sublime Text 3 stubs
Copied from the Javatar plugin (https://github.com/spywhere/Javatar) and adjusted to run some tests of the TerminalView plugin.
